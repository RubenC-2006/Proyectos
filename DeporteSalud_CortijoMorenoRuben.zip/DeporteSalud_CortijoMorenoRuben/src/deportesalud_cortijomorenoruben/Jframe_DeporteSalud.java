package deportesalud_cortijomorenoruben;


import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ruben
 */

public class Jframe_DeporteSalud extends javax.swing.JFrame {

    /**
     * Creates new form Jframe_DeporteSalud
     */
    
    private Image ImagenOriginalLocal = null;
    private Image ImagenOriginalWeb = null;
    
    public Jframe_DeporteSalud() {
        initComponents();
        Entrenamientos();
        GridBagSalud();
        
        jLabel_Imagenes.addComponentListener(new java.awt.event.ComponentAdapter() {
        @Override
        public void componentResized(java.awt.event.ComponentEvent e) {
            if (ImagenOriginalLocal != null) {
                escalarImagenes(ImagenOriginalLocal);
            } else if (ImagenOriginalWeb != null) {
                escalarImagenes(ImagenOriginalWeb);
            }
        }
        });
    }

    private void Entrenamientos(){
        jComboBox_Entrenamiento.removeAllItems();
        jComboBox_Entrenamiento.addItem("Cardio");
        jComboBox_Entrenamiento.addItem("Fuerza");
        jComboBox_Entrenamiento.addItem("Yoga");
        
        jButton_Añadir.addActionListener(e -> {
            String item = jTextField_TextoNuevo.getText().trim();
            if (!item.isEmpty()) {
                jComboBox_Entrenamiento.addItem(item);
                jTextField_TextoNuevo.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Añade un entrenamiento: ", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });
    }

    
    private void GridBagSalud() {
        jPanel_Salud.removeAll();
        jPanel_Salud.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6,6,6,6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        jPanel_Salud.add(new JLabel("Peso (kg):"), gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        jPanel_Salud.add(new JTextField(8), gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        jPanel_Salud.add(new JLabel("Altura (cm):"), gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        jPanel_Salud.add(new JTextField(8), gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; gbc.weightx = 0;
        gbc.fill = GridBagConstraints.NONE;
        JButton btnGuardar = new JButton("Guardar");
        jPanel_Salud.add(btnGuardar, gbc);

        jPanel_Salud.revalidate();
        jPanel_Salud.repaint();
    }

    private void escalarImagenes(Image img) {
        if (img == null) return;
        int ancho = 250;
        int alto = 150;

        Image scaled = img.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        jLabel_Imagenes.setIcon(new ImageIcon(scaled));
        jLabel_Imagenes.setText(null);
    }

    private void cargarImagenDesdeArchivo(File f) {
        try {
            Image img = ImageIO.read(f);
            if (img != null) {
                ImagenOriginalLocal = img;
                SwingUtilities.invokeLater(() -> escalarImagenes(ImagenOriginalLocal));
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar la imagen: " + ex.getMessage());
        }
    }

    private void cargarImagenDesdeWebAsync(String urlString) {
        new Thread(() -> {
            try {
                URL url = new URL(urlString);
                Image img = ImageIO.read(url);
                if (img != null) {
                    ImagenOriginalWeb = img;
                    SwingUtilities.invokeLater(() -> escalarImagenes(ImagenOriginalWeb));
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(this, "No se pudo cargar imagen web:\n" + ex.getMessage())
                );
            }
        }).start();
    }

    private void seleccionarImagenConDialog() {
            JFileChooser fc = new JFileChooser();
            int res = fc.showOpenDialog(this);
            if (res == JFileChooser.APPROVE_OPTION) {
                File f = fc.getSelectedFile();
                new Thread(() -> cargarImagenDesdeArchivo(f)).start();
            }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel_Salud = new javax.swing.JPanel();
        jPanel_Imagenes = new javax.swing.JPanel();
        jLabel_Imagenes = new javax.swing.JLabel();
        jButton_SeleccionarImagen = new javax.swing.JButton();
        jButton_CargarWeb = new javax.swing.JButton();
        jComboBox_Entrenamiento = new javax.swing.JComboBox<>();
        jTextField_TextoNuevo = new javax.swing.JTextField();
        jButton_Añadir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel_SaludLayout = new javax.swing.GroupLayout(jPanel_Salud);
        jPanel_Salud.setLayout(jPanel_SaludLayout);
        jPanel_SaludLayout.setHorizontalGroup(
            jPanel_SaludLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel_SaludLayout.setVerticalGroup(
            jPanel_SaludLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel_Imagenes.setPreferredSize(new java.awt.Dimension(300, 200));

        jButton_SeleccionarImagen.setText("Seleccionar imagen");
        jButton_SeleccionarImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SeleccionarImagenActionPerformed(evt);
            }
        });

        jButton_CargarWeb.setText("Cargar imagen desde web");
        jButton_CargarWeb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_CargarWebActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel_ImagenesLayout = new javax.swing.GroupLayout(jPanel_Imagenes);
        jPanel_Imagenes.setLayout(jPanel_ImagenesLayout);
        jPanel_ImagenesLayout.setHorizontalGroup(
            jPanel_ImagenesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_ImagenesLayout.createSequentialGroup()
                .addComponent(jLabel_Imagenes, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_ImagenesLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton_SeleccionarImagen)
                .addGap(61, 61, 61))
            .addGroup(jPanel_ImagenesLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jButton_CargarWeb)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel_ImagenesLayout.setVerticalGroup(
            jPanel_ImagenesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_ImagenesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_Imagenes, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton_SeleccionarImagen)
                .addGap(18, 18, 18)
                .addComponent(jButton_CargarWeb)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jComboBox_Entrenamiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jTextField_TextoNuevo.setColumns(6);
        jTextField_TextoNuevo.setToolTipText("");

        jButton_Añadir.setText("Añadir");
        jButton_Añadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AñadirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(72, Short.MAX_VALUE)
                        .addComponent(jPanel_Salud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField_TextoNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton_Añadir)
                            .addComponent(jComboBox_Entrenamiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jPanel_Imagenes, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jComboBox_Entrenamiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField_TextoNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton_Añadir)
                .addGap(18, 18, 18)
                .addComponent(jPanel_Salud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 117, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel_Imagenes, javax.swing.GroupLayout.DEFAULT_SIZE, 369, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_SeleccionarImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SeleccionarImagenActionPerformed
        seleccionarImagenConDialog();
    }//GEN-LAST:event_jButton_SeleccionarImagenActionPerformed

    private void jButton_CargarWebActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_CargarWebActionPerformed
        String url = JOptionPane.showInputDialog(this, "Introduce la URL de la imagen:");
        if (url != null && !url.trim().isEmpty()) {
            cargarImagenDesdeWebAsync(url);
        }
    }//GEN-LAST:event_jButton_CargarWebActionPerformed

    private void jButton_AñadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AñadirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton_AñadirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            } 
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Jframe_DeporteSalud.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Jframe_DeporteSalud().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Añadir;
    private javax.swing.JButton jButton_CargarWeb;
    private javax.swing.JButton jButton_SeleccionarImagen;
    private javax.swing.JComboBox<String> jComboBox_Entrenamiento;
    private javax.swing.JLabel jLabel_Imagenes;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel_Imagenes;
    private javax.swing.JPanel jPanel_Salud;
    private javax.swing.JTextField jTextField_TextoNuevo;
    // End of variables declaration//GEN-END:variables
}
